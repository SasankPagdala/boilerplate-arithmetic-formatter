import re 

def arithmetic_arranger(problems, solve=False):

  #Defining variables
  highest_line = ""
  lowest_line = ""
  dash_line = ""
  solution_line = ""
  
  #Error for too many problems
  if len(problems) > 5:
    return "Error: Too many problems."
  
  for equation in problems:
    new_list = equation.split()
    first = new_list[0]
    operator = new_list[1]
    second = new_list[2]

    #Defining the errors starts
    if operator=="*" or operator=="/":
      return "Error: Operator must be '+' or '-'."

    if len(first)>4 or len(second)>4:
      return "Error: Numbers cannot be more than four digits."

    if re.search("[^\d]",first) or re.search("[^\d\+\-]",second):
      return "Error: Numbers must only contain digits."



      

    #Defining for the answers starts
    answer=""
    if operator=="+":
      answer=str(int(first)+ int(second))
    elif operator == "-":
      answer=str(int(first) - int(second))




    #Defining for Max line
    line_length=max(len(first),len(second))+2


    #Defining single numerator 
    first_line=""
    first_line = str(first.rjust(line_length))

    #Defining single denominator=
    second_line=""
    second_line =str(operator) + str(second.rjust(line_length - 1))
    

    #Defining single dash 
    dash=""
    for p in range(line_length):
      dash +="-"
    

    #Defining single answer 
    answer_line=""
    answer_line += answer.rjust(line_length)
    


    #Arranging each line in syntactical order
    if equation != problems[-1]:
      highest_line += first_line + "    "
      lowest_line += second_line + "    "
      dash_line += dash + "    "
      solution_line += answer_line + "    "
    else:
      highest_line += first_line 
      lowest_line += second_line 
      dash_line += dash 
      solution_line += answer_line
    




  #Shaping the answers in proper order
  if solve==True:
    arranged_line = highest_line + "\n" + lowest_line + "\n" + dash_line + "\n" + solution_line
  else:
    arranged_line = highest_line + "\n" + lowest_line + "\n" + dash_line


   
  return arranged_line